OTF and TTF: Wicked Mouse (Regular and 3D)
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net

Hold onto your hats folks! Wicked Mouse is a playful display font that captures the magic of cartoons from a distant era. Basic latin, punctuation, extended latin, and diacritics are included in the full versions. Lowercase characters differ slightly in variation and rotation in the regular version while they 
mirror their uppercase counterparts in the 3D one. Do check the included glyph maps for all the characters. (slight overlap to be expected with some of the characters) Wacky, childlike, and loose in nature, you'll be able to inject a bit of fun with this typeface into a drab project. Use Wicked Mouse
for a children's book, web pages, or a fun logo design. Unleash your inner kid! 

Thank you for your support!

visit www.sharkshock.net for more and take a bite out of BORING design!

tags: retro, display, font, typeface, publishing, logo, title, book, cover, magazine, company, style, brand, branding, kid, sans, san serif, TV, cartoon, cartoons, saturday, Disney, Mickey, character, like, poster, headline, Porky, animation, children, children's, kids, playful, wacky, fun, funny, comedy




